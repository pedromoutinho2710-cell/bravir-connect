import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { formatBRL, formatDate } from "@/lib/format";
import { Loader2, PlusCircle, Clock, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { MARCAS } from "@/lib/constants";
import { PedidoDetalhesDialog } from "@/components/pedido/PedidoDetalhesDialog";
import { usePullToRefresh } from "@/hooks/usePullToRefresh";

type MeuPedido = {
  id: string;
  numero_pedido: number;
  tipo: string;
  data_pedido: string;
  status: string;
  status_atualizado_em: string | null;
  cond_pagamento: string | null;
  motivo: string | null;
  razao_social: string;
  marcas: string[];
  total: number;
  responsavel_id: string | null;
  responsavel_nome: string | null;
};

import { STATUS_LABEL, STATUS_COLOR } from "@/lib/status";
export { STATUS_LABEL, STATUS_COLOR };

const NOTIF: Record<string, (num: number, motivo?: string) => string> = {
  faturado:                (n) => `Pedido #${n} foi faturado!`,
  em_faturamento:          (n) => `Pedido #${n} está sendo processado pelo faturamento.`,
  devolvido:               (n, m) => `Pedido #${n} foi devolvido${m ? `: ${m}` : "."}`,
  cancelado:               (n, m) => `Pedido #${n} foi cancelado${m ? `: ${m}` : "."}`,
  pendente:                (n, m) => `Pedido #${n} está pendente${m ? `: ${m}` : "."}`,
  revisao_necessaria:      (n, m) => `Pedido #${n} precisa de revisão${m ? `: ${m}` : "."}`,
  entregue:                (n) => `Pedido #${n} foi entregue!`,
  em_rota:                 (n) => `Pedido #${n} está em rota de entrega.`,
};

function tempoNoStatus(dt: string | null) {
  if (!dt) return null;
  try {
    return formatDistanceToNow(new Date(dt), { addSuffix: true, locale: ptBR });
  } catch {
    return null;
  }
}

export default function MeusPedidos() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [pedidos, setPedidos] = useState<MeuPedido[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  const [filtroStatus, setFiltroStatus] = useState("todos");
  const [filtroCliente, setFiltroCliente] = useState("");
  const [filtroMarca, setFiltroMarca] = useState("todas");
  const [filtroDataInicio, setFiltroDataInicio] = useState("");
  const [filtroDataFim, setFiltroDataFim] = useState("");

  const [detalhesId, setDetalhesId] = useState<string | null>(null);
  const [detalhesOpen, setDetalhesOpen] = useState(false);

  const [excluirAlvo, setExcluirAlvo] = useState<{ id: string; numero: number } | null>(null);
  const [excluindo, setExcluindo] = useState(false);

  const [excluirDevolvido, setExcluirDevolvido] = useState<string | null>(null);
  const [excluindoDevolvido, setExcluindoDevolvido] = useState(false);

  const carregar = () => setRefreshKey((k) => k + 1);
  usePullToRefresh(carregar);

  const carregarPedidos = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let query: any = supabase
        .from("pedidos")
        .select(`
          id, numero_pedido, tipo, data_pedido, status, status_atualizado_em,
          cond_pagamento, motivo, responsavel_id,
          clientes(razao_social, nome_parceiro),
          itens_pedido(total_item, produtos(marca))
        `)
        .eq("vendedor_id", user.id)
        .order("created_at", { ascending: false });

      if (filtroStatus !== "todos") query = query.eq("status", filtroStatus);
      if (filtroDataInicio) query = query.gte("data_pedido", filtroDataInicio);
      if (filtroDataFim) query = query.lte("data_pedido", filtroDataFim);

      const { data, error } = await query;
      if (error) { toast.error("Erro ao carregar pedidos"); return; }

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let lista: MeuPedido[] = (data ?? []).map((p: any) => {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const itensList = (p.itens_pedido ?? []) as any[];
        const marcas = [...new Set(itensList.map((i) => i.produtos?.marca).filter(Boolean))] as string[];
        return {
          id: p.id,
          numero_pedido: p.numero_pedido,
          tipo: p.tipo,
          data_pedido: p.data_pedido,
          status: p.status,
          status_atualizado_em: p.status_atualizado_em ?? null,
          cond_pagamento: p.cond_pagamento,
          motivo: p.motivo,
          razao_social: p.clientes?.nome_parceiro || p.clientes?.razao_social || "—",
          marcas,
          total: itensList.reduce((s: number, i) => s + Number(i.total_item), 0),
          responsavel_id: p.responsavel_id ?? null,
          responsavel_nome: null,
        };
      });

      // Filtros client-side
      if (filtroCliente.trim()) {
        const q = filtroCliente.trim().toLowerCase();
        lista = lista.filter((p) => p.razao_social.toLowerCase().includes(q));
      }
      if (filtroMarca !== "todas") {
        lista = lista.filter((p) => p.marcas.includes(filtroMarca));
      }

      // Buscar nomes dos responsáveis
      const responsavelIds = [...new Set(
        lista
          .map((p) => p.responsavel_id)
          .filter(Boolean) as string[]
      )];

      if (responsavelIds.length > 0) {
        const { data: perfis } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", responsavelIds);

        if (perfis) {
          const mapaResponsaveis: Record<string, string> = {};
          perfis.forEach((pf) => {
            mapaResponsaveis[pf.id] = pf.full_name || pf.email || "—";
          });
          lista = lista.map((p) => ({
            ...p,
            responsavel_nome: p.responsavel_id
              ? (mapaResponsaveis[p.responsavel_id] ?? null)
              : null,
          }));
        }
      }

      setPedidos(lista);
    } finally {
      setLoading(false);
    }
  }, [user, filtroStatus, filtroDataInicio, filtroDataFim, filtroCliente, filtroMarca]);

  useEffect(() => {
    carregarPedidos();
  }, [carregarPedidos, refreshKey]);

  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel(`meus-pedidos-${user.id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "pedidos", filter: `vendedor_id=eq.${user.id}` },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (payload: any) => {
          const { numero_pedido, status, motivo } = payload.new;
          const msg = NOTIF[status]?.(numero_pedido, motivo) ?? `Pedido #${numero_pedido}: ${STATUS_LABEL[status] ?? status}`;
          const isPositivo = ["faturado", "entregue", "em_rota", "em_faturamento"].includes(status);
          const isNegativo = ["devolvido", "cancelado", "revisao_necessaria", "pendente"].includes(status);
          if (isPositivo) toast.success(msg, { duration: 8000 });
          else if (isNegativo) toast.warning(msg, { duration: 10000 });
          else toast.info(msg, { duration: 6000 });
          setRefreshKey((k) => k + 1);
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user]);

  const limparFiltros = () => {
    setFiltroStatus("todos");
    setFiltroCliente("");
    setFiltroMarca("todas");
    setFiltroDataInicio("");
    setFiltroDataFim("");
  };

  const temFiltro = filtroStatus !== "todos" || filtroCliente || filtroMarca !== "todas" || filtroDataInicio || filtroDataFim;

  const abrirDetalhes = (id: string) => {
    const pedido = pedidos.find((p) => p.id === id);
    if (pedido?.status === "rascunho") {
      navigate("/novo-pedido", { state: { pedidoId: id } });
      return;
    }
    setDetalhesId(id);
    setDetalhesOpen(true);
  };

  const excluirPedidoDevolvido = async () => {
    if (!excluirDevolvido) return;
    setExcluindoDevolvido(true);
    const { error } = await supabase.from("pedidos").delete().eq("id", excluirDevolvido);
    setExcluindoDevolvido(false);
    if (error) { toast.error("Erro ao excluir pedido"); return; }
    toast.success("Pedido excluído");
    setPedidos((prev) => prev.filter((p) => p.id !== excluirDevolvido));
    setExcluirDevolvido(null);
    setDetalhesOpen(false);
  };

  const excluirPedido = async () => {
    if (!excluirAlvo) return;
    setExcluindo(true);
    await supabase.from("itens_pedido").delete().eq("pedido_id", excluirAlvo.id);
    const { error } = await supabase.from("pedidos").delete().eq("id", excluirAlvo.id);
    setExcluindo(false);
    if (error) { toast.error("Erro ao excluir pedido"); return; }
    toast.success(`Pedido #${excluirAlvo.numero} excluído`);
    setPedidos((prev) => prev.filter((p) => p.id !== excluirAlvo.id));
    setExcluirAlvo(null);
  };

  function StatusBadge({ status }: { status: string }) {
    return (
      <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium ${STATUS_COLOR[status] ?? "bg-gray-100 text-gray-800 border-gray-300"}`}>
        {STATUS_LABEL[status] ?? status}
      </span>
    );
  }

  const ETAPAS = [
    { key: "pendente_sankhya", label: "Pendente Sankhya" },
    { key: "no_sankhya", label: "No Sankhya" },
    { key: "faturado", label: "Faturado" },
    { key: "parcialmente_faturado", label: "Parc. Faturado" },
  ];

  function ProgressoEtapas({ status }: { status: string }) {
    if (status === "sem_estoque") {
      return (
        <div className="flex items-center gap-1 mt-1.5">
          <div className="h-2 w-2 rounded-full bg-amber-500" />
          <span className="text-[10px] font-medium text-amber-700">
            Pedido sem estoque
          </span>
        </div>
      );
    }
    const idx = ETAPAS.findIndex((e) => e.key === status);
    if (idx === -1) return null;
    return (
      <div className="flex items-center gap-0.5 mt-1.5 flex-wrap">
        {ETAPAS.map((e, i) => (
          <div key={e.key} className="flex items-center gap-0.5">
            <div className={`h-2 w-2 rounded-full flex-shrink-0 ${i < idx ? "bg-green-500" : i === idx ? "bg-primary" : "bg-muted-foreground/30"}`} />
            <span className={`text-[10px] whitespace-nowrap ${i === idx ? "font-medium text-foreground" : "text-muted-foreground"}`}>{e.label}</span>
            {i < ETAPAS.length - 1 && <div className="h-px w-2 bg-muted-foreground/30 mx-0.5" />}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 md:pb-0">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Meus Pedidos</h1>
          <p className="text-sm text-muted-foreground">
            Acompanhe seus pedidos em tempo real — notificações automáticas ao mudar de status
          </p>
        </div>
        <Button asChild className="hidden sm:flex">
          <Link to="/novo-pedido">
            <PlusCircle className="mr-2 h-4 w-4" />
            Novo Pedido
          </Link>
        </Button>
      </div>

      {/* Filtros */}
      <div className="flex flex-wrap items-center gap-3">
        <Select value={filtroStatus} onValueChange={setFiltroStatus}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os status</SelectItem>
            {Object.entries(STATUS_LABEL).map(([v, l]) => (
              <SelectItem key={v} value={v}>{l}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          placeholder="Buscar cliente…"
          value={filtroCliente}
          onChange={(e) => setFiltroCliente(e.target.value)}
          className="w-[180px]"
        />

        <Select value={filtroMarca} onValueChange={setFiltroMarca}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Marca" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todas">Todas as marcas</SelectItem>
            {MARCAS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
          </SelectContent>
        </Select>

        <Input
          type="date"
          value={filtroDataInicio}
          onChange={(e) => setFiltroDataInicio(e.target.value)}
          className="w-[140px]"
          title="Data inicial"
        />
        <Input
          type="date"
          value={filtroDataFim}
          onChange={(e) => setFiltroDataFim(e.target.value)}
          className="w-[140px]"
          title="Data final"
        />

        {temFiltro && (
          <Button variant="ghost" size="sm" onClick={limparFiltros}>
            Limpar filtros
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex h-48 items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      ) : (
        <>
          {/* Mobile: cards */}
          <div className="grid gap-3 md:hidden">
            {pedidos.length === 0 && (
              <p className="text-center text-muted-foreground py-12">Nenhum pedido encontrado</p>
            )}
            {pedidos.map((p) => (
              <Card key={p.id} className="cursor-pointer active:opacity-70" onClick={() => abrirDetalhes(p.id)}>
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-mono font-bold text-sm">#{p.numero_pedido}</span>
                      <div className="font-medium text-sm mt-0.5">{p.razao_social}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div>
                        <StatusBadge status={p.status} />
                        {p.responsavel_nome && (
                          <div className="text-xs text-muted-foreground mt-1">
                            Assumido por: <span className="font-medium">{p.responsavel_nome}</span>
                          </div>
                        )}
                        <ProgressoEtapas status={p.status} />
                      </div>
                      {p.responsavel_id === null && (
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setExcluirAlvo({ id: p.id, numero: p.numero_pedido }); }}
                          className="p-1 rounded text-muted-foreground/50 hover:text-destructive hover:bg-destructive/10 transition-colors"
                          title="Excluir pedido"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{formatDate(p.data_pedido)} · {p.tipo}</span>
                    <span className="font-semibold text-foreground">{formatBRL(p.total)}</span>
                  </div>
                  {p.status_atualizado_em && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {tempoNoStatus(p.status_atualizado_em)}
                    </div>
                  )}
                  {p.motivo && (
                    <div className="text-xs text-amber-700 bg-amber-50 rounded px-2 py-1">{p.motivo}</div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Desktop: tabela */}
          <div className="hidden md:block rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">#</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Pagamento</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>No status há</TableHead>
                  <TableHead className="w-8"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pedidos.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-12">
                      Nenhum pedido encontrado
                    </TableCell>
                  </TableRow>
                )}
                {pedidos.map((p) => (
                  <TableRow key={p.id} className="cursor-pointer hover:bg-muted/50" onClick={() => abrirDetalhes(p.id)}>
                    <TableCell className="font-mono font-semibold text-sm">#{p.numero_pedido}</TableCell>
                    <TableCell className="text-sm">{formatDate(p.data_pedido)}</TableCell>
                    <TableCell className="font-medium text-sm">{p.razao_social}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{p.tipo}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{p.cond_pagamento || "—"}</TableCell>
                    <TableCell className="text-right font-semibold text-sm">{formatBRL(p.total)}</TableCell>
                    <TableCell>
                      <StatusBadge status={p.status} />
                      {p.responsavel_nome && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Assumido por: <span className="font-medium">{p.responsavel_nome}</span>
                        </div>
                      )}
                      <ProgressoEtapas status={p.status} />
                      {p.motivo && (
                        <div className="text-xs text-muted-foreground mt-1 max-w-[200px] truncate" title={p.motivo}>
                          {p.motivo}
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {tempoNoStatus(p.status_atualizado_em) ?? "—"}
                    </TableCell>
                    <TableCell>
                      {p.responsavel_id === null && (
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setExcluirAlvo({ id: p.id, numero: p.numero_pedido }); }}
                          className="p-1 rounded text-muted-foreground/50 hover:text-destructive hover:bg-destructive/10 transition-colors"
                          title="Excluir pedido"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </>
      )}

      {/* FAB mobile */}
      <Link
        to="/novo-pedido"
        className="fixed bottom-6 right-4 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg md:hidden"
      >
        <PlusCircle className="h-6 w-6" />
      </Link>

      <PedidoDetalhesDialog
        pedidoId={detalhesId}
        open={detalhesOpen}
        onOpenChange={setDetalhesOpen}
        onCorrigir={detalhesId ? () => {
          setDetalhesOpen(false);
          navigate("/novo-pedido", { state: { pedidoId: detalhesId, corrigindo: true } });
        } : undefined}
        onExcluir={detalhesId && pedidos.find(p => p.id === detalhesId)?.status === "devolvido" ? () => {
          setExcluirDevolvido(detalhesId);
          setDetalhesOpen(false);
        } : undefined}
        onEditar={detalhesId ? () => {
          setDetalhesOpen(false);
          navigate("/novo-pedido", { state: { pedidoId: detalhesId, editando: true } });
        } : undefined}
      />

      <AlertDialog open={!!excluirDevolvido} onOpenChange={(o) => { if (!o) setExcluirDevolvido(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir pedido devolvido?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. O pedido será excluído permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={excluindoDevolvido}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={excluirPedidoDevolvido}
              disabled={excluindoDevolvido}
            >
              {excluindoDevolvido ? <Loader2 className="h-4 w-4 animate-spin" /> : "Excluir"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!excluirAlvo} onOpenChange={(o) => { if (!o) setExcluirAlvo(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir pedido?</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o pedido #{excluirAlvo?.numero}? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={excluindo}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={excluirPedido}
              disabled={excluindo}
            >
              {excluindo ? <Loader2 className="h-4 w-4 animate-spin" /> : "Excluir"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
